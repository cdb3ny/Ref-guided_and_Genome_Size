#load packages

library(ape)
library(geiger)
library(phytools)

#Read in data and tree (if not already from pgls)

data1 <- read.csv("gs_range_aves.csv")

data1$Area <- as.numeric(data1$Area)

tree1 <- read.tree("play4_noOG_recent.tree")

#Check to see the data has been read in correctly

str(data1)

#Tests to run for fit loop continuous

models <- c("BM", "OU", "EB", "lambda", "kappa", "delta", "white")

#run for each of the variables. First column is species names

big.output.list<-list()
j <- 2
for(j in 2:24){
  cat(paste("workingon",names(data1[j]),"data\n"))
  
  #give us our named data for the variable
  test <- data1[[j]]
  names(test)<-data1$Species
  
  #empty list for fitcontinous
  results.fitcontinuous.analyses <- list()
  
  #fitcontinuous loop
  for(k in 1:length(models)){
    cat(paste("workingon",models[k], "model\n"))
    results.fitcontinuous.analyses[[k]]<-fitContinuous(phy = tree1, 
                                                       dat = test, model = models[k])
  }
  
  #make empty matrix for output of fitcontinous
  
  result.comp <- as.data.frame(matrix(,7,7))
  colnames(result.comp) <- c("model", "AICc", "lnLik", "Sig2", "z0", "alpha", "Pagel")
  
  #fill table
  
  for(i in 1:7){
    result.comp[i,1] <- models[i]
    result.comp[i,2] <- results.fitcontinuous.analyses[[i]]$opt$aicc
    result.comp[i,3] <- results.fitcontinuous.analyses[[i]]$opt$lnL
    result.comp[i,4] <- results.fitcontinuous.analyses[[i]]$opt$sigsq
    result.comp[i,5] <- results.fitcontinuous.analyses[[i]]$opt$z0
    
    if(models[i] == "OU"){
      result.comp[i,6] <- results.fitcontinuous.analyses[[i]]$opt$alpha}
    
    else if(models[i]=="lambda" | models[i]=="kappa"| models[i]=="delta"){
      result.comp[i,7] <-results.fitcontinuous.analyses[[i]]$opt[[1]]
    }
    else{
      i<-i+1
    }
  }
  #write output
  
  write.csv(result.comp, paste(names(data1[j]),
                               "fit_continuous_output_table.csv"))  
  
  #result.comp.df<-as.data.frame(result.comp)
  
  big.output.list[[j-1]]<-result.comp
  
  #names(big.output.list[[j-1]])<-paste(names(plant_data[j]))
}
big.output.list[[1]]
 