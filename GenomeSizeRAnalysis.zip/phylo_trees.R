#read in data files (if not yet completed)

data1 <- read.csv("gs_range_aves.csv")
tree1 <- read.tree("play4_noOG_recent.tree")

gs1 <- data1$GS_ave
names(gs1) <- data1$Species

#Check names

name.check(tree1, gs1)
gs1

#Tree time

?contMap #map continuous trait evolution on the tree with phytools 
#function "contMap"

treeoutname_color <- contMap(tree = tree1, 
                             x = gs1, outline = T, 
                             lwd = 2)
plot(tree1)
str(data1)
treeoutname_color$tip.label

plot(treeoutname_color)

#COLOR TREE

plot(treeoutname_color, fsize=0.8, outline=F, legend=FALSE, 
     ylim=c(1-0.09*(Ntip(treeoutname_color$tree)-1), 
            Ntip(treeoutname_color$tree)),
     mar=c(0.4, 0.4, 0.4, 0.4))
add.color.bar(5, treeoutname_color$cols, title="Genome Size (pg)",
              lims=treeoutname_color$lims, digits=3, prompt=FALSE, x=0.1,
              y=1-0.04*(Ntip(treeoutname_color$tree)-1), 
              lwd=4, fsize=1, subtitle="")

#COLOR BLIND FRIENDLY TREE 

treeoutname_1 <- contMap(tree = tree1, 
                         x = gs1, outline = T, 
                         lwd = 2)
plot(tree1)

treeoutname_1$cols[]<-viridis(length(treeoutname_1$cols))

plot(treeoutname_1, fsize=0.8, outline=F, legend=FALSE, 
     ylim=c(1-0.09*(Ntip(treeoutname_1$tree)-1), 
            Ntip(treeoutname_1$tree)),
     mar=c(0.4, 0.4, 0.4, 0.4))
add.color.bar(5, treeoutname_1$cols, title="Genome Size (pg)",
              lims=treeoutname_1$lims, digits=3, prompt=FALSE, x=0.1,
              y=1-0.04*(Ntip(treeoutname_1$tree)-1), 
              lwd=4, fsize=1, subtitle="")
