#PGLS Script

#install necessary packages
#read in packages

library(caper) # ape included, analyses of phylogenetics and evolution, comparative analyses of phylogenetics and evolution
library(phytools) # phylogenetic tools for comparative biology
library(geiger) # analysis of evolutionary diversification
library(nlme) # linear and nonlinear mixed effects models
library(picante) # integrating phylogeny and ecology
library(viridis) # color-blind friendly color maps 
library(ggplot2) # create elegant data visualizations (plots) using the grammar of graphics
library(ggpubr) # 'ggplot2' based publication ready plots
library(gridExtra) # miscellaneous functions for "grid graphics"
library(Hmisc) # Harrell miscellaneous
library(corrplot) # visualization of a correlation matrix

#read in data

data1 <- read.csv("gs_range_aves.csv")
tree1 <- read.tree("play4_noOG_recent.tree")


#make empty matrix

output.table <- matrix(,nrow=21, ncol=8)
colnames(output.table) <- c("Variable", "Estimate", "St. Error", "t-value", 
                          "p-value", "r-square",
                          "Adj. r-square", "F-stat")

gspic <- pic(log(data1$GS_ave), phy=tree1)

#loop to fill matrix

for(i in 3:24){
  output.table[(i-2),1] <- names(data1[i])
  varpic <- pic(log(data1[[i]]), phy=tree1)
  picmod <- lm(gspic~varpic+0)
  testing <- summary(picmod)
  #estimate
  output.table[(i-2),2] <- testing$coefficients[1]
  #st error
  output.table[(i-2),3] <- testing$coefficients[2]
  #t-value
  output.table[(i-2),4] <- testing$coefficients[3]
  #p-value
  output.table[(i-2),5] <- testing$coefficients[4]
  #r-square
  output.table[(i-2),6] <- testing$r.squared
  #adj. R square
  output.table[(i-2),7] <- testing$adj.r.squared[1]
  #f stat
  output.table[(i-2),8] <- testing$fstatistic[1]
}

write.csv(output.table, "leucaena_gs_pic_results.csv")

#make a dataframe of our matrix

testing.table <- as.data.frame(output.table)

#making our new dataframe as numeric

for(i in 2:8){
testing.table[[i]] <- as.numeric(testing.table[[i]])
}

#get list of models that are significant at 0.01 level

sigresults <- testing.table$Variable[testing.table$`p-value`< 0.01]

#loop to make ggplot scatterplots with trendline
#gets you a bunch of pdfs

pdf("pic_plots.pdf", width=6, height=4.5)
for(i in 1:length(sigresults)){
var1pic <- pic(data1[[sigresults[i]]], phy=tree1)
p1 <- ggplot(,aes(x=var1pic, y=gspic))+geom_point()+
  geom_smooth(method=lm, level=0.95, colour="red")+
  ylab("PIC for log(GS)")+xlab(paste(sigresults[i],"PIC"))+
  theme_minimal()+theme(axis.text=element_text(color="black"))


plot(p1)

}
dev.off()

#pic.sig.plots[8][1]


#will give you a summary plot
plist <- list()
z <- 1
for (z in 1:8){
  n<-18
  k<-pic(data1[[sigresults[z]]], phy=tree1)
  l<-gspic
  tmp<-numeric(n)
  data <- data.frame(n, k, l, tmp)
  
  plist[[z]] <- ggplot(data=data,aes(x=k, y=l))+geom_point()+
    geom_smooth(method=lm, level=0.95, colour="red")+
    ylab("PIC for log(GS)")+xlab(paste(sigresults[z],"PIC"))+
    theme_minimal()+theme(axis.text=element_text(color="black"))

  plot(plist[[z]])
}
do.call(ggarrange, c(plist, ncol = 2, nrow=4, labels="AUTO"))



####pairwise comparisons####
#make new object where we remove anything that isn't a climatic variable

data2 <- data1
data2$Species <- NULL
data2$GS_ave <- NULL
data2$Elevation <- NULL
data2$Area <- NULL
data2$Latitude <- NULL
str(data2)

#simple correlation table
mydata.cor <- cor(data2)

#install.packages("Hmisc")
#allows pairwise comparisons with p values (P) as well as correlations (r)

mydata.rcorr <- rcorr(as.matrix(data2))
?rcorr

#install.packages("corrplot")

#allows correlation plots
#plot of just correlations

corrplot(mydata.cor)

#plot of correlation p-values

col <- colorRampPalette(c("#BB4444", "#EE9988", "#FFFFFF", 
                          "#77AADD", "#4477AA"))

#correlation plot showing correlation and significance

par(mfrow=c(1,2))
corrplot(mydata.rcorr$r, method="color", col=col(200), 
         diag=FALSE, addCoef.col="black", type="upper")

corrplot(mydata.rcorr$P, method="color", col=col(200), 
         diag=FALSE, addCoef.col="black", type="upper")

write.csv(mydata.rcorr$r, "pearsons_correlation_Leucaena.csv")
write.csv(mydata.rcorr$P, "pearsons_correlation_P-value_Leucaena.csv")

####Finding significant correlations to remove for multiple regression###
# Create a matrix of all pairwise combinations of variables

variable_combinations <- combn(names(data2), 2)
head(variable_combinations)
length(variable_combinations)

# Loop through each pair of variables and perform Pearson's correlation test

significant_correlations <- data.frame(
  Variable1 = character(),
  Variable2 = character(),
  Correlation = numeric(),
  P_Value = numeric(),
  stringsAsFactors = FALSE
)

for (i in 1:ncol(variable_combinations)) {
  variable1 <- data2[[variable_combinations[1, i]]]
  variable2 <- data2[[variable_combinations[2, i]]]
  
  correlation_test <- cor.test(log(variable1), log(variable2), 
                               method = "pearson")
  if (correlation_test$p.value < 0.001) {
    significant_correlations <- rbind(
      significant_correlations,
      c(
        variable_combinations[1, i],
        variable_combinations[2, i],
        correlation_test$estimate,
        correlation_test$p.value
      )
    )
  }
}

colnames(significant_correlations) <- c("Variable1", "Variable2", 
                                      "Correlation", "P-value")
print(significant_correlations)
str(significant_correlations)

#make correlations and p values numeric

significant_correlations$Correlation <- as.numeric(significant_correlations$Correlation)
significant_correlations$`P-value` <- as.numeric(significant_correlations$`P-value`)

#get negative correlation data
#first make empty dataframe

negcorr <- data.frame(
  Variable1 = character(),
  Variable2 = character(),
  Correlation = numeric(),
  P_Value = numeric(),
  stringsAsFactors = FALSE
)

#fill negative data

for(i in 1:nrow(significant_correlations)){
  if(significant_correlations$Correlation[i]<0){
    negcorr<-rbind(negcorr, significant_correlations[i,])
  }
}

#do the same for positive

poscorr <- data.frame(
  Variable1 = character(),
  Variable2 = character(),
  Correlation = numeric(),
  P_Value = numeric(),
  stringsAsFactors = FALSE
)

#fill positive dataframe

for(i in 1:nrow(significant_correlations)){
  if(significant_correlations$Correlation[i]>0){
    poscorr<-rbind(poscorr, significant_correlations[i,])
  }
}

#unique positive values from column 1

u1 <- unique(poscorr$Variable1)

#empty matrix of things that have autocorrelation to things in left column

poslist.toremove <- matrix(,nrow=1)
i <- 1
for(i in 1:length(u1)){
  vari <- u1[i]
  new <- poscorr$Variable2[poscorr$Variable1==vari]
  poslist.toremove <- c(poslist.toremove,new)
}

#unique names from variable 2

upos <- unique(poslist.toremove)

#unique negative things from column 1

u2 <- unique(negcorr$Variable1)
neglist.toremove<-matrix(,nrow=1)
for(i in 1:length(u2)){
  vari<-u2[i]
  new<-negcorr$Variable2[negcorr$Variable1==vari]
  neglist.toremove<-c(neglist.toremove,new)
}
uneg<-unique(neglist.toremove)

to.remove <- c(upos, uneg)
unique.to.remove <- unique(to.remove)

unique.both <- c(u1,u2)
unique.both.2 <- unique(unique.both)
length(unique.both.2)

#list of things that have collapsed correlations

to.keep <- setdiff(unique.both.2, unique.to.remove)
#names of all data variables
#coompre to all data, data2 is where additional variables were removed
full.set <- setdiff(names(data2), unique.to.remove)


####Multiple regression models####
#if we log transformed the correlation at 0.001--0.5992 r squared, p value of 0.01033

modellog <- lm(log(GS_ave)~log(Mean_Temp_Annual)+log(Mean_Diurnal_Range)+
               log(Isothermality)+log(Max_Temp_Warmest_Month)+log(Precip_Driest_Month)+
               log(Precip_Warmest_Qtr)+log(Precip_Coldest_Qtr), data=data1)

summary(modellog)

#model based on above correlations set at 0.001 threshold of significance--0.5367 
#r squared pvalue 0.01318 (same as 0.0005)

model3 <- lm(GS_ave ~ Mean_Temp_Annual+Mean_Diurnal_Range+Isothermality+
               Max_Temp_Warmest_Month+Precip_Driest_Month+Precip_Warmest_Qtr, 
             data=data1)

summary(model3)

#log transformed data--0.5835 r squared p value 0.00747

model3log <- lm(log(GS_ave) ~ log(Mean_Temp_Annual)+log(Mean_Diurnal_Range)+
                log(Isothermality)+log(Max_Temp_Warmest_Month)+log(Precip_Driest_Month)+
                log(Precip_Warmest_Qtr), data=data1)
summary(model3log)

#set at 0.01 significance--45.96 rsquared--p value 0.01172
model4 <- lm(GS_ave ~ Mean_Temp_Annual+Isothermality+Precip_Driest_Month+
               Precip_Warmest_Qtr, data=data1)
summary(model4)

#set at 0.05 significance--29.8% r squared p value 0.02298

model5 <- lm(GS_ave~Mean_Temp_Annual+Precip_Driest_Month, data=data1)

summary(model5)

#list of variables in lm model

full.set


#### Fit PGLS model with multiple predictors####

tree1$node.label <- NULL

plantgs <- comparative.data(tree1, data1, Species, vcv=TRUE, vcv.dim=3)

#we lose significance with PGLS

pgls_model <- pgls(log(GS_ave) ~ log(Mean_Temp_Annual)+log(Mean_Diurnal_Range)+
                     log(Isothermality)+log(Max_Temp_Warmest_Month)+
                     log(Precip_Driest_Month)+log(Precip_Warmest_Qtr)+
                     log(Precip_Coldest_Qtr),data=plantgs)

# Display summary of the PGLS model

summary(pgls_model)

###Do with PICs

gspic<-pic(log(data1$GS_ave), phy=tree1)

MTApic<-pic(log(data1$Mean_Temp_Annual), phy=tree1)
MDRpic<-pic(log(data1$Mean_Diurnal_Range), phy=tree1)
Isopic<-pic(log(data1$Isothermality), phy=tree1)
MTWMpic<-pic(log(data1$Max_Temp_Warmest_Month), phy=tree1)
PDMpic<-pic(log(data1$Precip_Driest_Month), phy=tree1)
PWQpic<-pic(log(data1$Precip_Warmest_Qtr), phy=tree1)
PCQpic<-pic(log(data1$Precip_Coldest_Qtr), phy=tree1)

picmodmult<-lm(gspic~MTApic+MDRpic+Isopic+MTWMpic+PDMpic+PWQpic+PCQpic+0)
summary(picmodmult)
