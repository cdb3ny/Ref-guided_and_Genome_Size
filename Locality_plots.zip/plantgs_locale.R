#read in occurence data
dat<-read.csv("plant_gs_locale.csv")
#make species a facotr
dat$Species<-as.factor(dat$Species)
levels(dat$Species)
#read in genome size data
datgs<-read.csv("Plant_GS.csv")
#species info as factor
datgs$Species<-as.factor(datgs$Species)
levels(datgs$Species)

library(ggplot2)
library(viridis)

i<-1
#make a file of Species, Genome Size, latitude, and Longitude
#this makes a table with the same GS for each lat/long info
newinfo<-matrix(,nrow=length(dat[,1]), ncol=4)
dat<-as.matrix(dat)
for(i in 1:length(dat[,1])){
  newinfo[i,1]<-dat[i,1]
  newinfo[i,2]<-datgs$GS[datgs$Species==dat[i,1]]
  newinfo[i,3]<-dat[i,3]
  newinfo[i,4]<-dat[i,4]
}
#make that matrix into a datafram with labels
newinfo2<-as.data.frame(newinfo)
names(newinfo2)<-c("Species", "GS", "lat", "long")
#speices as factor and other information as numeric
newinfo2$Species<-as.factor(newinfo2$Species)
newinfo2$GS<-as.numeric(newinfo2$GS)
newinfo2$lat<-as.numeric(newinfo2$lat)
newinfo2$long<-as.numeric(newinfo2$long)
newinfo2$lgGS<-as.numeric(log(newinfo2$GS))

#ggplot of just data points, can see it looks like shape of mexico, etc.
ggplot(newinfo2, aes(y=lat, x=long, color=GS))+geom_point(size=(newinfo2$GS),
                                                                    alpha=0.4)+
  scale_color_viridis_c(end=0.9)


#read in maps package to be able to plot world map
library(maps)
worldmap<-map_data("world")

#plot of occurence on map colored by genome size
ggplot()+geom_polygon(data=worldmap, aes(x=long, y=lat, group=group), fill="lightgrey", color="grey")+
  geom_point(data=newinfo2, aes(x=long, y=lat, color=GS),alpha=0.6, size=2)+
coord_fixed(ratio=1.3, xlim=c((-1+min(newinfo2$long)), 1+max(newinfo2$long)),
              ylim=c(-1+min(newinfo2$lat), (1+max(newinfo2$lat))))+
  scale_color_viridis_c(end=0.9, name="Genome Size \n(pg)")+
  theme_bw()+ylab("Latitude")+xlab("Longitude")+
  ggtitle(expression("Observations of"~italic("Leucaena")~"with Genome Size"))+
  theme(axis.title=element_text(size=14), axis.text=element_text(size=12, color="black"),
  title = element_text(size=14), legend.title = element_text(size=12),
        legend.text=element_text(size=12), legend.key.size = unit(1, 'cm'))


#install.packages("forcats")
library(forcats)

ggplot()+geom_polygon(data=worldmap, aes(x=long, y=lat, group=group), fill="lightgrey", color="grey")+
  geom_point(shape=21, data=newinfo2, aes(x=long, y=lat, fill=GS),color="grey20", alpha=0.6, size=2)+
  coord_fixed(ratio=1.3, xlim=c((-1+min(newinfo2$long)), 1+max(newinfo2$long)),
              ylim=c(-1+min(newinfo2$lat), (1+max(newinfo2$lat))))+
  scale_fill_viridis_c(end=0.9, name="Genome Size \n(pg)")+
  theme_bw()+ylab("Latitude")+xlab("Longitude")+
  ggtitle(expression("Observations of"~italic("Leucaena")~"with Genome Size"))+
  theme(axis.title=element_text(size=14), axis.text=element_text(size=8, color="black"))+
  theme(title = element_text(size=14), legend.title = element_text(size=12),
        legend.text=element_text(size=12), legend.key.size = unit(1, 'cm'))+
  facet_wrap(~fct_reorder(Species,GS))


#making a table of summary info for species
#for latitude
#modify to be "max distance from equator" (absolute value then max)
#span equator? negative min and positive max
#range.  if both positive, then max-min. if both negative, then abs(min)-abs(max)
#if max positive and minimum negative, then abs(min)+max
#i<-1
sum.info.names<-c("Species", "GS", "Min_Lat", "Max_Lat", "Mean_Dist_Eq", "SpanEq", "Lat_Range", "Min_Long", "Max_Long", "Long_Range", "Area")
sum.info<-matrix(,nrow=length(levels(newinfo2$Species)), ncol=length(sum.info.names))
for(i in 1:length(levels(newinfo2$Species))){
test<-subset(newinfo2, newinfo2$Species==levels(newinfo2$Species)[i])
minlat<-min(test$lat)
maxlat<-max(test$lat)
minlong<-min(test$long)
maxlong<-max(test$long)
sum.info[i,1]<-levels(newinfo2$Species)[i]
sum.info[i,2]<-mean(test$GS)
sum.info[i,3]<-minlat
sum.info[i,4]<-maxlat
sum.info[i,5]<-if (abs(minlat) > abs(maxlat)){abs(minlat)} else {mean(test$lat)}
sum.info[i,6]<-(if(minlat < 0 & maxlat > 0){"yes"}
               else{"no"})
sum.info[i,7]<-(if(maxlat > 0 & minlat >0){maxlat-minlat}
               else if(maxlat > 0 & minlat < 0){abs(minlat)+maxlat}
               else {abs(minlat)-abs(maxlat)})
sum.info[i,8]<-minlong
sum.info[i,9]<-maxlong
sum.info[i,10]<-(if(maxlong > 0 & minlong >0){maxlong-minlong}
                 else if(maxlong > 0 & minlong < 0){abs(minlong)+maxlong}
                 else {abs(minlong)-abs(maxlong)})
sum.info[i,11]<-(as.numeric((sum.info[i,7]))*as.numeric((sum.info[i,10])))

}
#make matrix into dataframe with most informaiton as numeric, species as factor
sum.info.df<-data.frame(sum.info)
colnames(sum.info.df)<-sum.info.names
str(sum.info.df)
sum.info.df$Species<-as.factor(sum.info.df$Species)
sum.info.df$GS<-as.numeric(sum.info.df$GS)
sum.info.df$Min_Lat<-as.numeric(sum.info.df$Min_Lat)
sum.info.df$Max_Lat<-as.numeric(sum.info.df$Max_Lat)
sum.info.df$Lat_Range<-as.numeric(sum.info.df$Lat_Range)
sum.info.df$Mean_Dist_Eq<-as.numeric(sum.info.df$Mean_Dist_Eq)
sum.info.df$Min_Long<-as.numeric(sum.info.df$Min_Long)
sum.info.df$Max_Long<-as.numeric(sum.info.df$Max_Long)
sum.info.df$Long_Range<-as.numeric(sum.info.df$Long_Range)
sum.info.df$Area<-as.numeric(sum.info.df$Area)

write.csv(sum.info.df, "occurence_averages_Leucaena_Oct_8_2023.csv")

#p-value=0.01479, adj. r-squared 0.261
min.lat<-summary(lm(GS~Min_Lat, data=sum.info.df))
#p-value=0.01124, adj. r-squared 0.2824
max.lat<-summary(lm(GS~Max_Lat, data=sum.info.df))
#p-value=0.001817, adj. r-squared 0.4121
mean.dist<-summary(lm(GS~Mean_Dist_Eq, data=sum.info.df))
#p-value=0.5528, adj. r-squared -0.03295
lat.range<-summary(lm(GS~Lat_Range, data=sum.info.df))
#p-value=0.1176, adj. r-squared 0.08713
min.long<-summary(lm(GS~Min_Long, data=sum.info.df))
#p-value=0.0.07805, adj. r-squared 0.1227
max.long<-summary(lm(GS~Max_Long, data=sum.info.df))
#p-value=0.8746, adj. r-squared -0.5723
long.range<-summary(lm(GS~Long_Range, data=sum.info.df))
#p-value=0.4532, adj. r-squared -0.2334
area<-summary(lm(GS~Area, data=sum.info.df))

g1<-ggplot(data=sum.info.df, aes(x=Min_Lat, y=GS))+
  geom_point(size=3)+ 
  geom_smooth(method = "lm", col="red")+
  ylim(1,2)+
  ggtitle("GS ~ Min Lat")+
  annotate("text", x=4, y=1.98, 
           label=("y = 0.0092x + 1.385\np = 0.0148"),
           size=4, hjust=1)+
  annotate("text", x=4, y=1.86,
           label=expression("Adj."~R^2~"=0.261"),
           size=4, hjust=1, parse=TRUE)+
  theme_bw()+
  theme(axis.title =element_text(size=14),
        axis.text=element_text(size=14, color="black"))

#label=expression("Adj."~R^2~"= 0.08248"), size=4, parse=TRUE)
g2<-ggplot(data=sum.info.df, aes(x=Max_Lat, y=GS))+
  geom_point(size=3)+ 
  geom_smooth(method = "lm", col="red")+
  ylim(1,2)+
  ggtitle("GS ~ Max Lat")+
  annotate("text", x=22, y=1.98, 
           label=("y = 0.0133x + 1.241\np = 0.0112"),
           size=4, hjust=1)+
  annotate("text", x=22, y=1.86,
           label=expression("Adj."~R^2~"=0.282"),
           size=4, hjust=1, parse=TRUE)+
  theme_bw()+
  theme(axis.title =element_text(size=14),
        axis.text=element_text(size=14))
# min(sum.info.df$Max_Lat)+0.5*(max(sum.info.df$Max_Lat)-min(sum.info.df$Max_Lat))
# max(sum.info.df$Max_Lat)
mean.dist
g3<-ggplot(data=sum.info.df, aes(x=Mean_Dist_Eq, y=GS))+
  geom_point(size=3)+ 
  geom_smooth(method = "lm", col="red")+
  ylim(1,2)+
  ggtitle("GS ~ Mean Dist. From Equator")+
  annotate("text", x=15, y=1.98, 
           label=("y = 0.0147x + 1.269\np = 0.00182"),
           size=4, hjust=1)+
  annotate("text", x=15, y=1.85,
           label=expression("Adj."~R^2~"= 0.412"),
           size=4, hjust=1, parse=TRUE)+
  theme_bw()+
  theme( axis.title =element_text(size=14),
         axis.text=element_text(size=14))
lat.range
g4<-ggplot(data=sum.info.df, aes(x=Lat_Range, y=GS))+
  geom_point(size=3)+
  geom_smooth(method = "lm")+
  ylim(1,2)+
  ggtitle("GS ~ Lat_Range (not sig)")+
  annotate("text", x=30, y=1.98, 
           label=("y = -0.0028x + 1.538\np = 0.5228"),
           size=4, hjust=1)+
  annotate("text", x=30, y=1.86,
           label=expression("Adj."~R^2~"= -0.0330"),
           size=4, hjust=1, parse=TRUE)+
  theme_bw()+
  theme(axis.title =element_text(size=14),
        axis.text=element_text(size=14))
min.long
g5<-ggplot(data=sum.info.df, aes(x=Min_Long, y=GS))+
  geom_point(size=3)+ 
  geom_smooth(method = "lm")+
  ylim(1,2)+
  ggtitle("GS ~ Min Long (not sig)")+
  annotate("text", x=-80, y=1.98, 
           label=("y = -0.0058x + 0.955\np = 0.118"),
           size=4, hjust=1)+
  annotate("text", x=-80, y=1.86,
           label=expression("Adj."~R^2~"= 0.0871"),
           size=4, hjust=1, parse=TRUE)+
  theme_bw()+
  theme(axis.title =element_text(size=14),
        axis.text=element_text(size=14))
max.long
g6<-ggplot(data=sum.info.df, aes(x=Max_Long, y=GS))+
  geom_point(size=3)+ 
  geom_smooth(method = "lm")+
  ylim(1,2)+
  ggtitle("GS ~ Max Long (not sig)")+
  annotate("text", x=-65, y=1.98, 
           label=("y = -0.00674 + 0.9112\np = 0.0781"),
           size=4, hjust=1)+
  annotate("text", x=-65, y=1.86,
           label=expression("Adj."~R^2~"= 0.1227"),
           size=4, hjust=1, parse=TRUE)+
  theme_bw()+
  theme( axis.title =element_text(size=14),
         axis.text=element_text(size=14))
long.range
g7<-ggplot(data=sum.info.df, aes(x=Long_Range, y=GS))+
  geom_point(size=3)+ 
  geom_smooth(method = "lm")+
  ylim(1,2)+
  ggtitle("GS ~ Long Range (not sig)")+
  annotate("text", x=20, y=1.98, 
           label=("y = --0.00088x + 1.526\np = 0.875"),
           size=4, hjust=1)+
  annotate("text", x=20, y=1.86,
           label=expression("Adj."~R^2~"= -0.0572"),
           size=4, hjust=1, parse=TRUE)+
  theme_bw()+
  theme(axis.title =element_text(size=14),
        axis.text=element_text(size=14))
area
g8<-ggplot(data=sum.info.df, aes(x=Area, y=GS))+
  geom_point(size=3)+ 
  geom_smooth(method = "lm")+
  ylim(1,2)+
  ggtitle("GS ~ Area (not sig)")+
  annotate("text", x=450, y=1.98, 
           label=("y = -0.000213x + 1.535\np = 0.4532"),
           size=4, hjust=1)+
  annotate("text", x=450, y=1.86,
           label=expression("Adj."~R^2~"= -0.02334"),
           size=4, hjust=1, parse=TRUE)+
  theme_bw()+
  theme(axis.title =element_text(size=14),
        axis.text=element_text(size=14))
#combo plot
library(ggpubr)
ggarrange(g1, g2, g3, g4, g5, g6, g7, g8, labels=c("A","B", "C", "D", "E", "F", "G", "H"))
####Plotting tree on map with colors for genome size####

#install.packages("phytools")
library(phytools)
#make sure you have updated version (1.9.16)
packageVersion("phytools")

#planttree<-read.tree("play4_noOG_recent.tree")
planttree<-marg_probs
plot(planttree)

#str(newinfo2)

# occur<-data.frame(newinfo2$Species, newinfo2$lat, newinfo2$long)
# str(occur)
# colnames(occur)<-c("Species", "lat", "long")
#make matrix of just lat long info for species
testagain<-data.frame(newinfo2$lat, newinfo2$long)
colnames(testagain)<-c("lat", "long")
testagain2<-as.matrix(testagain)
rownames(testagain2)<-newinfo2$Species
#maek phylomap object
plant.phymap<-phylo.to.map(stable, testagain2, plot=FALSE)
library(viridis)
#set a list of colors to correspond to the species names
#g9 is build to get the list of colors used for each species by genome size
str(sum.info.df)
g9<-ggplot(data=sum.info.df, aes(x=Area, y=GS, col=GS))+geom_point(size=3)+ geom_smooth(method = "lm")+
  scale_color_viridis_c(end=0.9)+
  ggtitle("Genome Size ~ Area (not sig)")+theme(axis.title =element_text(size=14),
                                                axis.text=element_text(size=14))

#getting list of colors
p<-ggplot_build(g9)
color.list<-p$data[[1]]["colour"]
sum.info.df$Species
#put the list of colors which correspond here
coltest<-setNames(color.list$colour, sum.info.df$Species)

#plot the three rightwards, set limits for map
plot(plant.phymap,direction="rightwards", xlim=c(-115, -65), ylim=c(-17, 35),
     fsize=1, ftype="i", asp=1, lty="solid", map.bg="grey",
     lwd=0.5, pts=FALSE, colors=coltest, cex.points=0.8, delimit_map=TRUE)


stable<-read.tree("stable_traits_tree.new")
plot(stable)
